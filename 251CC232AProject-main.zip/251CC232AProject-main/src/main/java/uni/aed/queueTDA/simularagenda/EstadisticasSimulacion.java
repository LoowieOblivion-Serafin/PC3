package uni.aed.queueTDA.simularagenda;

import uni.aed.queueTDA.QueueTDA;
import uni.aed.queueTDA.LinkedQueueTDA;

/**
 * Clase responsable de calcular y mantener las estadísticas de la simulación
 */
public class EstadisticasSimulacion {
    private double tiempoEsperaPromedio;
    private int[] tiempoEsperaMaximoPorPrioridad;    // Índices 0-4 para prioridades 1-5
    private double[] tiempoEsperaPromedioPorPrioridad; // Índices 0-4 para prioridades 1-5
    private int[] contadorPorPrioridad;              // Contador de trabajos por prioridad
    private int[] sumaTiemposPorPrioridad;           // Suma de tiempos de espera por prioridad

    public EstadisticasSimulacion() {
        this.tiempoEsperaMaximoPorPrioridad = new int[5];
        this.tiempoEsperaPromedioPorPrioridad = new double[5];
        this.contadorPorPrioridad = new int[5];
        this.sumaTiemposPorPrioridad = new int[5];

        // Inicializar arrays
        for (int i = 0; i < 5; i++) {
            tiempoEsperaMaximoPorPrioridad[i] = 0;
            tiempoEsperaPromedioPorPrioridad[i] = 0.0;
            contadorPorPrioridad[i] = 0;
            sumaTiemposPorPrioridad[i] = 0;
        }
    }

    /**
     * Calcula todas las estadísticas basándose en los trabajos finalizados
     * @param trabajosFinalizados cola con todos los trabajos finalizados
     */
    public void calcularEstadisticas(QueueTDA<Job> trabajosFinalizados) {
        if (trabajosFinalizados.isEmpty()) {
            tiempoEsperaPromedio = 0.0;
            return;
        }

        // Reiniciar contadores
        for (int i = 0; i < 5; i++) {
            tiempoEsperaMaximoPorPrioridad[i] = 0;
            contadorPorPrioridad[i] = 0;
            sumaTiemposPorPrioridad[i] = 0;
        }

        // Crear una cola temporal para recorrer sin modificar la original
        QueueTDA<Job> colaTemp = new LinkedQueueTDA<>();
        int totalTrabajos = 0;
        int sumaTotalTiempos = 0;

        // Primera pasada: extraer todos los trabajos y calcular estadísticas
        while (!trabajosFinalizados.isEmpty()) {
            Job job = trabajosFinalizados.dequeue();
            colaTemp.enqueue(job);

            int tiempoEspera = job.getTiempoEspera();
            int prioridadIndex = job.getPrioridad() - 1; // Convertir prioridad 1-5 a índice 0-4

            // Actualizar estadísticas generales
            totalTrabajos++;
            sumaTotalTiempos += tiempoEspera;

            // Actualizar estadísticas por prioridad
            contadorPorPrioridad[prioridadIndex]++;
            sumaTiemposPorPrioridad[prioridadIndex] += tiempoEspera;

            // Actualizar tiempo máximo por prioridad
            if (tiempoEspera > tiempoEsperaMaximoPorPrioridad[prioridadIndex]) {
                tiempoEsperaMaximoPorPrioridad[prioridadIndex] = tiempoEspera;
            }
        }

        // Restaurar la cola original
        while (!colaTemp.isEmpty()) {
            trabajosFinalizados.enqueue(colaTemp.dequeue());
        }

        // Calcular tiempo de espera promedio general
        tiempoEsperaPromedio = (double) sumaTotalTiempos / totalTrabajos;

        // Calcular tiempos de espera promedio por prioridad
        for (int i = 0; i < 5; i++) {
            if (contadorPorPrioridad[i] > 0) {
                tiempoEsperaPromedioPorPrioridad[i] =
                        (double) sumaTiemposPorPrioridad[i] / contadorPorPrioridad[i];
            } else {
                tiempoEsperaPromedioPorPrioridad[i] = 0.0;
            }
        }
    }

    /**
     * Muestra un reporte detallado de las estadísticas
     */
    public void mostrarReporteDetallado() {
        System.out.println("\n=== REPORTE DETALLADO DE ESTADÍSTICAS ===");
        System.out.println("Tiempo de espera promedio general: " +
                String.format("%.2f", tiempoEsperaPromedio) + " minutos");
        System.out.println();

        System.out.println("Estadísticas por nivel de prioridad:");
        System.out.println("Prioridad | Trabajos | Tiempo Prom. | Tiempo Máx.");
        System.out.println("----------|----------|--------------|------------");

        for (int i = 0; i < 5; i++) {
            System.out.printf("    %d     |    %3d   |    %6.2f    |     %3d    %n",
                    (i + 1),
                    contadorPorPrioridad[i],
                    tiempoEsperaPromedioPorPrioridad[i],
                    tiempoEsperaMaximoPorPrioridad[i]);
        }
        System.out.println("==========================================\n");
    }

    // Getters
    public double getTiempoEsperaPromedio() {
        return tiempoEsperaPromedio;
    }

    public int[] getTiempoEsperaMaximoPorPrioridad() {
        return tiempoEsperaMaximoPorPrioridad.clone();
    }

    public double[] getTiempoEsperaPromedioPorPrioridad() {
        return tiempoEsperaPromedioPorPrioridad.clone();
    }

    public int[] getContadorPorPrioridad() {
        return contadorPorPrioridad.clone();
    }
}

