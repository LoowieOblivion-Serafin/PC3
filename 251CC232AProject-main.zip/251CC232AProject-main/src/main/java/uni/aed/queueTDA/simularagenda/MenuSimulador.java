package uni.aed.queueTDA.simularagenda;
import java.util.Scanner;
/**
 * Clase que maneja la interfaz de usuario y el menú principal
 */

public class MenuSimulador {
    private SimuladorAgenda simulador;
    private Scanner scanner;
    private boolean agendaCargada;

    public MenuSimulador() {
        this.simulador = new SimuladorAgenda();
        this.scanner = new Scanner(System.in);
        this.agendaCargada = false;
    }

    /**
     * Método principal que ejecuta el menú interactivo
     */
    public void ejecutarMenu() {
        int opcion;

        do {
            mostrarMenu();
            opcion = leerOpcion();
            procesarOpcion(opcion);
        } while (opcion != 6);

        scanner.close();
        System.out.println("¡Gracias por usar el Simulador de Agenda de Trabajo!");
    }

    /**
     * Muestra el menú principal
     */
    private void mostrarMenu() {
        System.out.println("\n" + "=".repeat(50));
        System.out.println("    SIMULADOR DE AGENDA DE TRABAJO");
        System.out.println("=".repeat(50));
        System.out.println("a) Cargar Agenda de Trabajo");
        System.out.println("b) Obtener el tiempo de espera promedio");
        System.out.println("c) Obtener el tiempo de espera máximo por nivel de prioridad");
        System.out.println("d) Eliminar actual Agenda de Trabajo");
        System.out.println("e) Visualizar Agenda de Trabajo");
        System.out.println("6) Salir");
        System.out.println("=".repeat(50));
        System.out.print("Seleccione una opción: ");
    }

    /**
     * Lee la opción seleccionada por el usuario
     * @return número de opción seleccionada
     */
    private int leerOpcion() {
        String input = scanner.nextLine().trim().toLowerCase();

        // Convertir letras a números para facilitar el procesamiento
        switch (input) {
            case "a": return 1;
            case "b": return 2;
            case "c": return 3;
            case "d": return 4;
            case "e": return 5;
            case "6": return 6;
            default:
                System.out.println("Opción inválida. Por favor, intente nuevamente.");
                return 0;
        }
    }

    /**
     * Procesa la opción seleccionada por el usuario
     * @param opcion opción a procesar
     */
    private void procesarOpcion(int opcion) {
        switch (opcion) {
            case 1:
                cargarAgendaTrabajo();
                break;
            case 2:
                obtenerTiempoEsperaPromedio();
                break;
            case 3:
                obtenerTiempoEsperaMaximo();
                break;
            case 4:
                eliminarAgendaTrabajo();
                break;
            case 5:
                visualizarAgendaTrabajo();
                break;
            case 6:
                System.out.println("Saliendo del programa...");
                break;
            case 0:
                // Opción inválida ya manejada en leerOpcion()
                break;
            default:
                System.out.println("Opción no implementada.");
        }
    }

    /**
     * Opción a) Cargar Agenda de Trabajo
     */
    private void cargarAgendaTrabajo() {
        System.out.println("\n=== CARGAR AGENDA DE TRABAJO ===");

        try {
            System.out.print("Ingrese el número de minutos a simular (M): ");
            int minutosSimulacion = Integer.parseInt(scanner.nextLine().trim());

            if (minutosSimulacion <= 0) {
                System.out.println("Error: El número de minutos debe ser mayor a 0.");
                return;
            }

            System.out.print("Ingrese el número máximo de trabajos concurrentes (N): ");
            int maxTrabajosConcurrentes = Integer.parseInt(scanner.nextLine().trim());

            if (maxTrabajosConcurrentes <= 0) {
                System.out.println("Error: El número de trabajos concurrentes debe ser mayor a 0.");
                return;
            }

            // Ejecutar la simulación
            simulador.cargarAgendaTrabajo(minutosSimulacion, maxTrabajosConcurrentes);
            agendaCargada = true;

            System.out.println("\n¡Agenda de trabajo cargada y simulación completada exitosamente!");

            // Mostrar reporte automáticamente
            simulador.getEstadisticas().mostrarReporteDetallado();

        } catch (NumberFormatException e) {
            System.out.println("Error: Por favor ingrese números válidos.");
        } catch (Exception e) {
            System.out.println("Error inesperado: " + e.getMessage());
        }
    }

    /**
     * Opción b) Obtener el tiempo de espera promedio
     */
    private void obtenerTiempoEsperaPromedio() {
        System.out.println("\n=== TIEMPO DE ESPERA PROMEDIO ===");

        if (!agendaCargada) {
            System.out.println("Error: Debe cargar una agenda de trabajo primero (opción a).");
            return;
        }

        double tiempoPromedio = simulador.obtenerTiempoEsperaPromedio();
        System.out.println("Tiempo de espera promedio: " +
                String.format("%.2f", tiempoPromedio) + " minutos");

        // Mostrar también estadísticas por prioridad
        double[] tiemposPromedios = simulador.getEstadisticas().getTiempoEsperaPromedioPorPrioridad();
        System.out.println("\nTiempo de espera promedio por prioridad:");
        for (int i = 0; i < tiemposPromedios.length; i++) {
            System.out.println("- Prioridad " + (i + 1) + ": " +
                    String.format("%.2f", tiemposPromedios[i]) + " minutos");
        }
    }

    /**
     * Opción c) Obtener el tiempo de espera máximo por nivel de prioridad
     */
    private void obtenerTiempoEsperaMaximo() {
        System.out.println("\n=== TIEMPO DE ESPERA MÁXIMO POR PRIORIDAD ===");

        if (!agendaCargada) {
            System.out.println("Error: Debe cargar una agenda de trabajo primero (opción a).");
            return;
        }

        int[] tiemposMaximos = simulador.obtenerTiempoEsperaMaximoPorPrioridad();

        System.out.println("Tiempo de espera máximo por nivel de prioridad:");
        for (int i = 0; i < tiemposMaximos.length; i++) {
            System.out.println("- Prioridad " + (i + 1) + ": " + tiemposMaximos[i] + " minutos");
        }
    }

    /**
     * Opción d) Eliminar actual Agenda de Trabajo
     */
    private void eliminarAgendaTrabajo() {
        System.out.println("\n=== ELIMINAR AGENDA DE TRABAJO ===");

        if (!agendaCargada) {
            System.out.println("No hay agenda de trabajo cargada actualmente.");
            return;
        }

        System.out.print("¿Está seguro de que desea eliminar la agenda actual? (s/n): ");
        String confirmacion = scanner.nextLine().trim().toLowerCase();

        if (confirmacion.equals("s") || confirmacion.equals("si")) {
            simulador.eliminarAgendaTrabajo();
            agendaCargada = false;
            System.out.println("Agenda de trabajo eliminada exitosamente.");
        } else {
            System.out.println("Operación cancelada.");
        }
    }

    /**
     * Opción e) Visualizar Agenda de Trabajo
     */
    private void visualizarAgendaTrabajo() {
        if (!agendaCargada) {
            System.out.println("\nNo hay agenda de trabajo cargada actualmente.");
            System.out.println("Por favor, use la opción 'a' para cargar una agenda primero.");
            return;
        }

        simulador.visualizarAgendaTrabajo();
    }

    /**
     * Método main para ejecutar el programa
     */
    public static void main(String[] args) {
        System.out.println("Iniciando Simulador de Agenda de Trabajo...");
        System.out.println("Código de estudiante: [TU_CODIGO]");

        MenuSimulador menu = new MenuSimulador();
        menu.ejecutarMenu();
    }
}


