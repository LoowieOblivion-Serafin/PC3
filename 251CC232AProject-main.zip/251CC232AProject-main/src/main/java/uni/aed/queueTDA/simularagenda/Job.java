package uni.aed.queueTDA.simularagenda;

/**
 * Código de estudiante: 20221565E
 * Clase que representa un trabajo en la simulación
 */

public class Job implements Comparable<Job> {
    private int id;                    // Identificador único del trabajo
    private int prioridad;            // Prioridad del trabajo (1-5, siendo 1 la más alta)
    private int tiempoEjecucion;      // Tiempo necesario para ejecutar el trabajo
    private int tiempoLlegada;        // Minuto en que llegó el trabajo
    private int tiempoInicio;         // Minuto en que comenzó a ejecutarse
    private int tiempoFinalizacion;   // Minuto en que terminó de ejecutarse
    private boolean enEjecucion;      // Indica si está siendo ejecutado
    private boolean finalizado;       // Indica si ya terminó

    public Job(int id, int prioridad, int tiempoEjecucion, int tiempoLlegada) {
        this.id = id;
        this.prioridad = prioridad;
        this.tiempoEjecucion = tiempoEjecucion;
        this.tiempoLlegada = tiempoLlegada;
        this.enEjecucion = false;
        this.finalizado = false;
        this.tiempoInicio = -1;
        this.tiempoFinalizacion = -1;
    }

    /**
     * Implementación de compareTo para la cola de prioridad
     * Menor valor de prioridad = mayor prioridad (1 es más prioritario que 5)
     */
    @Override
    public int compareTo(Job otro) {
        // Comparación por prioridad (menor número = mayor prioridad)
        if (this.prioridad != otro.prioridad) {
            return Integer.compare(this.prioridad, otro.prioridad);
        }
        // Si tienen la misma prioridad, el que llegó primero tiene prioridad
        return Integer.compare(this.tiempoLlegada, otro.tiempoLlegada);
    }

    /**
     * Calcula el tiempo de espera del trabajo
     * @return tiempo de espera en minutos
     */
    public int getTiempoEspera() {
        if (tiempoInicio == -1) {
            return -1; // Aún no ha comenzado
        }
        return tiempoInicio - tiempoLlegada;
    }

    /**
     * Inicia la ejecución del trabajo
     * @param minutoActual minuto en que comienza la ejecución
     */
    public void iniciarEjecucion(int minutoActual) {
        this.tiempoInicio = minutoActual;
        this.enEjecucion = true;
    }

    /**
     * Procesa un minuto de ejecución
     * @return true si el trabajo ha terminado
     */
    public boolean procesarMinuto() {
        if (enEjecucion && !finalizado) {
            tiempoEjecucion--;
            if (tiempoEjecucion <= 0) {
                finalizado = true;
                enEjecucion = false;
                return true;
            }
        }
        return false;
    }

    // Getters y Setters
    public int getId() { return id; }
    public int getPrioridad() { return prioridad; }
    public int getTiempoEjecucion() { return tiempoEjecucion; }
    public int getTiempoLlegada() { return tiempoLlegada; }
    public int getTiempoInicio() { return tiempoInicio; }
    public int getTiempoFinalizacion() { return tiempoFinalizacion; }
    public boolean isEnEjecucion() { return enEjecucion; }
    public boolean isFinalizado() { return finalizado; }

    public void setTiempoFinalizacion(int tiempoFinalizacion) {
        this.tiempoFinalizacion = tiempoFinalizacion;
    }

    @Override
    public String toString() {
        return String.format("Job[ID:%d, Prioridad:%d, TiempoEjec:%d, Llegada:%d, Espera:%d]",
                id, prioridad, tiempoEjecucion, tiempoLlegada, getTiempoEspera());
    }
}

