package uni.aed.queueTDA.simularagenda;

import uni.aed.queueTDA.PriorityQueueTDA;
import uni.aed.queueTDA.LinkedQueueTDA;
import uni.aed.queueTDA.QueueTDA;
import java.util.Random;

/**
 * Clase principal que maneja la simulación de la agenda de trabajo
 */

public class SimuladorAgenda {
    private PriorityQueueTDA<Job> colaEspera;        // Cola de prioridad para trabajos en espera
    private QueueTDA<Job> trabajosEjecutandose;      // Cola de trabajos en ejecución
    private QueueTDA<Job> trabajosFinalizados;       // Cola de trabajos finalizados
    private int minutosSimulacion;                    // Número de minutos a simular
    private int maxTrabajosConcurrentes;             // Máximo número de trabajos concurrentes
    private Random random;                           // Generador de números aleatorios
    private int contadorJobs;                        // Contador para IDs únicos
    private EstadisticasSimulacion estadisticas;     // Estadísticas de la simulación

    public SimuladorAgenda() {
        this.colaEspera = new PriorityQueueTDA<>();
        this.trabajosEjecutandose = new LinkedQueueTDA<>();
        this.trabajosFinalizados = new LinkedQueueTDA<>();
        this.random = new Random();
        this.contadorJobs = 1;
        this.estadisticas = new EstadisticasSimulacion();
    }

    /**
     * Carga y ejecuta la simulación de la agenda de trabajo
     * @param minutosSimulacion número de minutos a simular
     * @param maxTrabajosConcurrentes máximo número de trabajos que pueden ejecutarse concurrentemente
     */
    public void cargarAgendaTrabajo(int minutosSimulacion, int maxTrabajosConcurrentes) {
        this.minutosSimulacion = minutosSimulacion;
        this.maxTrabajosConcurrentes = maxTrabajosConcurrentes;

        // Limpiar estructuras previas
        limpiarAgenda();

        System.out.println("=== INICIANDO SIMULACIÓN ===");
        System.out.println("Minutos a simular: " + minutosSimulacion);
        System.out.println("Trabajos concurrentes máximos: " + maxTrabajosConcurrentes);
        System.out.println();

        // Ejecutar simulación minuto a minuto
        for (int minuto = 1; minuto <= minutosSimulacion; minuto++) {
            procesarMinuto(minuto);
        }

        // Procesar trabajos restantes en cola al final de la simulación
        procesarTrabajosRestantes();

        // Calcular estadísticas finales
        estadisticas.calcularEstadisticas(trabajosFinalizados);

        System.out.println("=== SIMULACIÓN COMPLETADA ===");
        System.out.println("Total de trabajos procesados: " + (contadorJobs - 1));
        System.out.println("Trabajos finalizados: " + trabajosFinalizados.size());
        System.out.println("Trabajos en cola: " + colaEspera.size());
    }

    /**
     * Procesa un minuto de la simulación
     * @param minutoActual minuto actual de la simulación
     */
    private void procesarMinuto(int minutoActual) {
        // 1. Llega un nuevo trabajo cada minuto
        Job nuevoJob = generarTrabajoAleatorio(minutoActual);
        colaEspera.enqueue(nuevoJob);

        // 2. Procesar trabajos en ejecución
        procesarTrabajosEnEjecucion(minutoActual);

        // 3. Asignar nuevos trabajos si hay capacidad disponible
        asignarNuevosTrabajosAEjecucion(minutoActual);

        // Mostrar estado cada 10 minutos para seguimiento
        if (minutoActual % 10 == 0) {
            mostrarEstadoSimulacion(minutoActual);
        }
    }

    /**
     * Genera un trabajo con parámetros aleatorios
     * @param tiempoLlegada minuto en que llega el trabajo
     * @return nuevo trabajo generado
     */
    private Job generarTrabajoAleatorio(int tiempoLlegada) {
        int prioridad = random.nextInt(5) + 1;        // Prioridad entre 1 y 5
        int tiempoEjecucion = random.nextInt(10) + 1; // Tiempo entre 1 y 10 minutos

        return new Job(contadorJobs++, prioridad, tiempoEjecucion, tiempoLlegada);
    }

    /**
     * Procesa los trabajos que están en ejecución
     * @param minutoActual minuto actual de la simulación
     */
    private void procesarTrabajosEnEjecucion(int minutoActual) {
        QueueTDA<Job> trabajosEnProceso = new LinkedQueueTDA<>();

        // Procesar cada trabajo en ejecución
        while (!trabajosEjecutandose.isEmpty()) {
            Job job = trabajosEjecutandose.dequeue();

            if (job.procesarMinuto()) {
                // El trabajo ha terminado
                job.setTiempoFinalizacion(minutoActual);
                trabajosFinalizados.enqueue(job);
            } else {
                // El trabajo continúa en ejecución
                trabajosEnProceso.enqueue(job);
            }
        }

        // Restaurar trabajos que siguen en ejecución
        trabajosEjecutandose = trabajosEnProceso;
    }

    /**
     * Asigna nuevos trabajos a ejecución si hay capacidad disponible
     * @param minutoActual minuto actual de la simulación
     */
    private void asignarNuevosTrabajosAEjecucion(int minutoActual) {
        // Mientras haya capacidad y trabajos en espera
        while (trabajosEjecutandose.size() < maxTrabajosConcurrentes && !colaEspera.isEmpty()) {
            Job job = colaEspera.dequeue();
            job.iniciarEjecucion(minutoActual);
            trabajosEjecutandose.enqueue(job);
        }
    }

    /**
     * Procesa trabajos restantes en cola al final de la simulación
     */
    private void procesarTrabajosRestantes() {
        int minutoExtra = minutosSimulacion + 1;

        while (!colaEspera.isEmpty() || !trabajosEjecutandose.isEmpty()) {
            // Procesar trabajos en ejecución
            procesarTrabajosEnEjecucion(minutoExtra);

            // Asignar nuevos trabajos
            asignarNuevosTrabajosAEjecucion(minutoExtra);

            minutoExtra++;
        }
    }

    /**
     * Muestra el estado actual de la simulación
     * @param minuto minuto actual
     */
    private void mostrarEstadoSimulacion(int minuto) {
        System.out.println("--- Minuto " + minuto + " ---");
        System.out.println("En cola: " + colaEspera.size());
        System.out.println("Ejecutándose: " + trabajosEjecutandose.size());
        System.out.println("Finalizados: " + trabajosFinalizados.size());
        System.out.println();
    }

    /**
     * Obtiene el tiempo de espera promedio general
     * @return tiempo de espera promedio
     */
    public double obtenerTiempoEsperaPromedio() {
        return estadisticas.getTiempoEsperaPromedio();
    }

    /**
     * Obtiene el tiempo de espera máximo por nivel de prioridad
     * @return array con tiempos máximos por prioridad [1-5]
     */
    public int[] obtenerTiempoEsperaMaximoPorPrioridad() {
        return estadisticas.getTiempoEsperaMaximoPorPrioridad();
    }

    /**
     * Elimina la agenda actual y reinicia el simulador
     */
    public void eliminarAgendaTrabajo() {
        limpiarAgenda();
        contadorJobs = 1;
        System.out.println("Agenda de trabajo eliminada exitosamente.");
    }

    /**
     * Limpia todas las estructuras de datos
     */
    private void limpiarAgenda() {
        colaEspera.clear();
        trabajosEjecutandose.clear();
        trabajosFinalizados.clear();
        estadisticas = new EstadisticasSimulacion();
    }

    /**
     * Visualiza el estado actual de la agenda de trabajo
     */
    public void visualizarAgendaTrabajo() {
        System.out.println("\n=== VISUALIZACIÓN DE AGENDA DE TRABAJO ===");
        System.out.println("Parámetros de simulación:");
        System.out.println("- Minutos simulados: " + minutosSimulacion);
        System.out.println("- Trabajos concurrentes máximos: " + maxTrabajosConcurrentes);
        System.out.println();

        System.out.println("Estado actual:");
        System.out.println("- Trabajos en cola de espera: " + colaEspera.size());
        System.out.println("- Trabajos en ejecución: " + trabajosEjecutandose.size());
        System.out.println("- Trabajos finalizados: " + trabajosFinalizados.size());
        System.out.println();

        // Mostrar estadísticas si hay trabajos finalizados
        if (trabajosFinalizados.size() > 0) {
            System.out.println("=== ESTADÍSTICAS ===");
            System.out.println("Tiempo de espera promedio: " +
                    String.format("%.2f", obtenerTiempoEsperaPromedio()) + " minutos");

            System.out.println("\nTiempo de espera máximo por prioridad:");
            int[] tiemposMaximos = obtenerTiempoEsperaMaximoPorPrioridad();
            for (int i = 0; i < tiemposMaximos.length; i++) {
                System.out.println("- Prioridad " + (i + 1) + ": " + tiemposMaximos[i] + " minutos");
            }

            System.out.println("\nTiempo de espera promedio por prioridad:");
            double[] tiemposPromedios = estadisticas.getTiempoEsperaPromedioPorPrioridad();
            for (int i = 0; i < tiemposPromedios.length; i++) {
                System.out.println("- Prioridad " + (i + 1) + ": " +
                        String.format("%.2f", tiemposPromedios[i]) + " minutos");
            }
        }

        System.out.println("==========================================\n");
    }

    // Getters para acceso a las estructuras (para testing)
    public PriorityQueueTDA<Job> getColaEspera() { return colaEspera; }
    public QueueTDA<Job> getTrabajosFinalizados() { return trabajosFinalizados; }
    public EstadisticasSimulacion getEstadisticas() { return estadisticas; }
}


